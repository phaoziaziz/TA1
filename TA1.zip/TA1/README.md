# TA1
ini merupakan code dari ta yang saya kumpulkan
